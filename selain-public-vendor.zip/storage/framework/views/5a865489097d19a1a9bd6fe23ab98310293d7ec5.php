        <!-- Page wrapper  -->
<!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <?php if(auth()->user()->level == 'admin'): ?>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/beranda')); ?>"
                                aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
                                    class="hide-menu">Dashboard</span></a>
                        </li>
                        <?php endif; ?>
                        <?php if(auth()->user()->level == 'siswa'): ?>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/siswa/dashboard')); ?>"
                                aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
                                    class="hide-menu">Dashboard</span></a>
                        </li>
                        <?php endif; ?>
                        <?php if(auth()->user()->level == 'orang tua'): ?>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/orang_tua/dashboard')); ?>"
                                aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
                                    class="hide-menu">Dashboard</span></a>
                        </li>
                        <?php endif; ?>
                        
                         <?php if(auth()->user()->level == 'siswa'): ?>
                         <li class="list-divider"></li>
                         <li class="nav-small-cap"><span class="hide-menu">Data Saldo</span></li>
                         <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i class="icon-wallet"></i><span
                                    class="hide-menu">Lihat Saldo
                                </span></a>
                            <ul aria-expanded="false" class="collapse first-level base-level-line">
                                <li class="sidebar-item"><a href="<?php echo e(url('/siswa/tabungan/rincian')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Rincian Saldo </span></a></li>

                                <li class="sidebar-item"><a href="<?php echo e(url('/siswa/tabungan/total')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Total Saldo </span></a></li>
                            </ul>
                        </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->user()->level == 'siswa'): ?>
                        <li class="list-divider"></li>
                        <li class="nav-small-cap"><span class="hide-menu">Pembayaran</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/siswa/pembayaran')); ?>"
                                aria-expanded="false">
                                <i class="icon-basket"></i>
                                <span class="hide-menu">Pembayaran</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(auth()->user()->level == 'orang tua'): ?>
                        <li class="list-divider"></li>
                         <li class="nav-small-cap"><span class="hide-menu">Data Saldo</span></li>
                         
                         <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i class="icon-wallet"></i><span
                                    class="hide-menu">Lihat Saldo
                                </span></a>
                            <ul aria-expanded="false" class="collapse first-level base-level-line">
                                <li class="sidebar-item"><a href="<?php echo e(url('/orang_tua/tabungan/rincian')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Rincian Saldo </span></a></li>

                                <li class="sidebar-item"><a href="<?php echo e(url('/orang_tua/tabungan/total')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Total Saldo </span></a></li>
                            </ul>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(auth()->user()->level == 'admin'): ?>
                        <li class="list-divider"></li>
                        <li class="nav-small-cap"><span class="hide-menu">Data Pengguna</span></li>
                        
                        <li class="sidebar-item"> <a class="sidebar-link" href="<?php echo e(url('/siswa')); ?>"
                                aria-expanded="false"><i class="icon-user"></i><span
                                    class="hide-menu">Siswa
                                </span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/orang_tua')); ?>"
                                aria-expanded="false">
                                <i class="icon-people"></i>
                                <span class="hide-menu">Orang Tua</span>
                            </a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/admin')); ?>"
                                aria-expanded="false"><i class="icon-user-follow"></i><span
                                    class="hide-menu">Admin</span></a></li>

                        <li class="list-divider"></li>
                        <li class="nav-small-cap"><span class="hide-menu">Data Kelas & Tapel</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/kelas')); ?>"
                                aria-expanded="false"><i class="icon-chart"></i><span
                                    class="hide-menu">Kelas </span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/tapel')); ?>"><i class="icon-calender"></i><span
                                    class="hide-menu">Tahun Pelajaran </span></a>
                        </li>

                        <li class="list-divider"></li>
                        <li class="nav-small-cap"><span class="hide-menu">Data Tabungan</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i class="icon-wallet"></i><span
                                    class="hide-menu">Tabungan
                                </span></a>
                            <ul aria-expanded="false" class="collapse first-level base-level-line">
                                <li class="sidebar-item"><a href="<?php echo e(url('/tabungan/tambah')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Input Data Tabungan </span></a></li>

                                <li class="sidebar-item"><a href="<?php echo e(url('/tabungan')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Lihat Data Rincian  Tabungan </span></a></li>
                                <li class="sidebar-item"><a href="<?php echo e(url('/tabungan/total_tabungan')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Lihat Total Saldo </span></a></li>
                            </ul>
                        </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->user()->level == 'admin'): ?>
                        <li class="list-divider"></li>

                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo e(url('/sms')); ?>"><i class="icon-bubble"></i><span
                                    class="hide-menu">Kirim Pesan</span></a>
                        </li>
                        <?php endif; ?>
                        <li class="list-divider"></li>
                        
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="/logout"
                                aria-expanded="false"><i data-feather="log-out" class="feather-icon"></i><span
                                    class="hide-menu">Logout</span></a></li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== --><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/layout/slidebar.blade.php ENDPATH**/ ?>