

<?php $__env->startSection('title'); ?>
  Data Orang Tua
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Data Orang Tua
<?php $__env->stopSection(); ?>


<?php $__env->startSection('link_halaman'); ?>
  <a href="<?php echo e(url('/beranda')); ?>">Dashboard </a> >> <a href="<?php echo e(url('/orang_tua')); ?>"> Orang tua</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->admin->nama_admin); ?>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('foto_user'); ?>
    <?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->admin->foto_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="data_table" class="table">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Wali Dari</th>
                                <th scope="col">Alamat</th>
                                <th scope="col">No HP</th>
                                <th scope="col" width="80px">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        		<?php $__currentLoopData = $data_orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        			<tr>
                        				<td scope="row"><?php echo e($loop->iteration); ?></td>
                        				<td><?php echo e($item->nama_orangtua); ?></td>
                        				<td><?php echo e($item->siswa->nama_siswa); ?></td>
                        				<td><?php echo e($item->alamat_orangtua); ?></td>
                        				<td><?php echo e($item->nohp_orangtua); ?></td>
										<td width="80px">
											<a href="#" class="btn btn-info" data-toggle="modal" data-target="#modalEdit-<?php echo e($item->id_orangtua); ?>">
												<i class="fas fa-edit"></i>
											</a>
										</td>
                        			</tr>
                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Start modal Edit -->
<?php $__currentLoopData = $data_orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ortu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalEdit-<?php echo e($ortu->id_orangtua); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ubah Data Orang Tua</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(url('/orang_tua/edit')); ?>" method="POST">
      <div class="modal-body">
         <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-start">
                            <h3 class="card-title mb-0">Data Orang Tua</h3>
                        </div>
                        <hr>
                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_orangtua" value="<?php echo e($ortu->id_orangtua); ?>">                                 	
                            <div class="form-group">
                            	<label for="nama_orangtua">Nama</label>
                            	<input name="nama_orangtua" type="text" class="form-control" id="nama_orangtua" value="<?php echo e($ortu->nama_orangtua); ?>">
                                <?php $__errorArgs = ['nama_orangtua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger text-sm">*Wajib Diisi</p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="alamat_orangtua">Alamat</label>
                                <input name="alamat_orangtua" type="text" class="form-control" id="alamat_orangtua" value="<?php echo e($ortu->alamat_orangtua); ?>">
                                <?php $__errorArgs = ['alamat_orangtua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger text-sm">*Wajib Diisi</p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="nohp_orangtua">No HP</label>
                                <input name="nohp_orangtua" type="number" class="form-control" id="nohp_orangtua" value="<?php echo e($ortu->nohp_orangtua); ?>">
                                <?php $__errorArgs = ['nohp_orangtua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger text-sm">*Wajib Diisi</p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>           
                    </div>
                </div>
            </div>
            
        </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Simpan">

      </div>
      </form>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- End modal Edit -->
                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
	$(document).on('submit', 'form', function(event) {
	 	event.preventDefault();
	 	$.ajax({
	 		url : $(this).attr('action'),
	 		type : $(this).attr('method'),
	 		typeData : "JSON",
	 		data : new FormData(this),
	 		processData:false,
	 		contentType:false,
	 		success : function(res) {
	 			console.log(res);
	 			window.location.href = "<?php echo e(url('/orang_tua')); ?>"
	 			const Toast = Swal.mixin({
                            toast : true,
                            position : 'top-end',
                            showConfirmButton : false,
                            timer : 3000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                        Toast.fire({
                            icon : 'success',
                            title : res.text
                        })
		 		},
		 		error : function (xhr) {
		 			// toastr.error(res.responseJSON.text, 'Gagal');
		 			Swal.fire({
					  position: 'top-end',
					  icon: 'error',
					  title: xhr.responseJSON.text,
					  showConfirmButton: false,
					  timer: 1500
					})
		 		} 
	 	})
	 });		
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/orang_tua/index.blade.php ENDPATH**/ ?>