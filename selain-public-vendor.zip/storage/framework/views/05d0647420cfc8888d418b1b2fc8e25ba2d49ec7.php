

<?php $__env->startSection('title'); ?>
  Dashboard Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Dashboard Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link_halaman'); ?>
  <a href="/siswa/dashboard">Dashboard Siswa</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->siswa->nama_siswa); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foto_user'); ?>
    <?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->siswa->foto_siswa); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- *************************************************************** -->
                <!-- Start First Cards -->
                <!-- *************************************************************** -->

                <div class="row">
                  <div class="col-12">
                    <div class="card text-white">
                      <div class="card-header bg-dark">
                        <h4 class="mb-0 text-white">Total Saldo</h4>
                      </div>

                      <div class="card-body">
                        <h2 class="card-title text-dark">Rp. <?php echo number_format($total_th, 0, ',', '.'); ?></h2>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="card-group">
                   
                    <div class="card mr-1">
                        <div class="card-body bg-danger">
                            <div class="d-flex d-lg-flex d-md-block align-items-center">
                                <div>
                                    <div class="d-inline-flex align-items-center">
                                        <h2 class="text-white mb-1 font-weight-medium">Rp. <?php echo number_format($total_hr, 0, ',', '.'); ?></h2>
                                    </div>
                                    <h6 class="font-weight-normal mb-0 w-100 text-white">Saldo Hari ini</h6>
                                </div>
                                <div class="ml-auto mt-md-3 mt-lg-0">
                                    <span class="opacity-7 text-muted"><i data-feather="file-plus"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body bg-success">
                            <div class="d-flex d-lg-flex d-md-block align-items-center">
                                <div>
                                    <h2 class="text-white mb-1 font-weight-medium">Rp. <?php echo number_format($total_bln, 0, ',', '.'); ?></h2>
                                    <h6 class="font-weight-normal mb-0 w-100 text-white">Saldo Bulan ini</h6>
                                </div>
                                <div class="ml-auto mt-md-3 mt-lg-0">
                                    <span class="opacity-7 text-muted"><i data-feather="globe"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- *************************************************************** -->
                <!-- End First Cards -->
                <!-- *************************************************************** -->
               
                
                <!-- *************************************************************** -->
                <!-- Start Location and Earnings Charts Section -->
                <!-- *************************************************************** -->
                 
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Grafik Jumlah Debit Tabungan</h4>
                                <div>
                                    <canvas id="line-chart-x" height="150"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- *************************************************************** -->
                <!-- End Location and Earnings Charts Section -->
                <!-- *************************************************************** -->
                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        // Dashboard 1 Morris-chart
$(function () {
    "use strict";

//Line Chart

    new Chart(document.getElementById("line-chart-x"), {
      type: 'line',
      data: {
        labels: <?php echo json_encode($tgl_chart_debit); ?>,
        datasets: [{ 
            data: <?php echo json_encode($nominal_chart_debit); ?>,
            label: "Nominal Debit",
            borderColor: "#5f76e8",
            fill: false
          },
          { 
            data: <?php echo json_encode($nominal_chart_kredit); ?>,
            label: "Nominal Kredit",
            borderColor: "rgba(1, 202, 241,1)",
            fill: false
          }
        ]
      },
      options: {
        title: {
          display: true,
          text: ''
        }
      }
    });

 });    

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/siswa/dashboard.blade.php ENDPATH**/ ?>