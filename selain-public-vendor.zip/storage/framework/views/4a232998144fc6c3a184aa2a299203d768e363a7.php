<?php
use Illuminate\Support\Facades\Crypt;
?>



<?php $__env->startSection('title'); ?>
  Data User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Edit Data User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
	<?php echo e(auth()->user()->admin->nama_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foto_user'); ?>
	<?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->admin->foto_admin); ?>

<?php $__env->stopSection(); ?>
	
<?php $__env->startSection('link_halaman'); ?>
  <a href="<?php echo e(url('/beranda')); ?>">Dashboard </a> >> Edit Data User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- *************************************************************** -->
                <!-- Start First Cards -->
                <!-- *************************************************************** -->

                <div class="row">
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex align-items-start">
                                    <h3 class="card-title mb-0">Data User</h3>
                                </div>
                                <hr>
                                <?php if(session('success')): ?>
                                	<div class="alert alert-success" role="alert">
                                		<?php echo e(session('success')); ?>

                                	</div>
                                <?php endif; ?>
                                <form action="<?php echo e(url('/user/edit_admin/')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
	                                	<label for="level"></label>
	                                	<input type="hidden" name="id_user" class="form-control" value="<?php echo e(auth()->user()->id_user); ?>">
	                                	<input name="level" type="hidden" class="form-control" id="level" value="<?php echo e(auth()->user()->level); ?>">
	                                	<input type="hidden" name="id_admin" value="<?php echo e($data_user[0]->id_user); ?>">                          	
	                                <div class="form-group">
	                                	<label for="username">Username</label>
	                                	<input name="username" type="text" class="form-control" id="username" value="<?php echo e($data_user[0]->username); ?>">
	                                </div>
	                                <div class="form-group">
	                                	<label for="old_password">Password Saat Ini</label>
	                                	<input name="old_password" type="password" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="old_password">
	                                	<?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                		<div class="text-danger mt-2"><?php echo e($message); ?></div>
	                                	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>

	                                <div class="form-group">
	                                	<label for="password">Password</label>
	                                	<input name="password" type="password" class="form-control" id="password">
	                                </div>
	                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                		<div class="text-danger mt-2"><?php echo e($message); ?></div>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                                <div class="form-group">
	                                	<label for="password_confirmation">Password Konfirmasi</label>
	                                	<input name="password_confirmation" type="password" class="form-control" id="password_confirmation">
	                                </div>
	                                
	                                <!-- <div class="form-group">
	                                	<label for="konfirmasi_password">Konfirmasi Password</label>
	                                	<input type="konfirmasi_password" class="form-control" id="konfirmasi_password">
	                                </div> -->

	                                <input type="submit" value="SIMPAN" class="form-control btn btn-primary mt-3" style="width: 15%">
                                </form>             
                            </div>
                        </div>
                    </div>
                    
                </div>


                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
	$(document).on('submit', 'form', function(event) {
	 	event.preventDefault();
	 	$.ajax({
	 		url : $(this).attr('action'),
	 		type : $(this).attr('method'),
	 		typeData : "JSON",
	 		data : new FormData(this),
	 		processData:false,
	 		contentType:false,
	 		success : function(res) {
	 			console.log(res);
	 			window.location.href = "<?php echo e(url('/user/edit_admin')); ?>/<?php echo e(auth()->user()->id_user); ?>/<?php echo e(auth()->user()->level); ?>"
	 			const Toast = Swal.mixin({
                            toast : true,
                            position : 'top-end',
                            showConfirmButton : false,
                            timer : 3000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                        Toast.fire({
                            icon : 'success',
                            title : res.text
                        })
		 		},
		 		error : function (xhr) {
		 			// toastr.error(res.responseJSON.text, 'Gagal');
		 			Swal.fire({
					  position: 'top-end',
					  icon: 'error',
					  title: xhr.responseJSON.text,
					  showConfirmButton: false,
					  timer: 1500
					})
		 		} 
	 	})
	 });		
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/user/edit_user_admin.blade.php ENDPATH**/ ?>