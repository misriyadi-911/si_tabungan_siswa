


<?php $__env->startSection('title'); ?>
	Data Kelas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Data Kelas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link_halaman'); ?>
  <a href="<?php echo e(url('/beranda')); ?>">Dashboard </a> >> <a href="<?php echo e(url('/kelas')); ?>"> Kelas</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->admin->nama_admin); ?>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('foto_user'); ?>
    <?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->admin->foto_admin); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->
<div class="row">
    <div class="col-12">
    	<a href="" class="btn btn-primary btn-sm rounded-pill mb-3 btn_tambah" data-toggle="modal" data-target="#modalTambah">
			<i class="fas fa-plus-circle"></i> Tambah Data Kelas
		</a>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="data_table" class="table">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col" style="width: 50%">Kelas</th>
                                <th scope="col" width="80px">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        		<?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        			<tr>
                        				<td scope="row"><?php echo e($loop->iteration); ?></td>
                        				<td style="width: 50%"><?php echo e($item->kelas); ?></td>
                        				<td width="80px">
											<a href="#" class="btn btn-info" data-toggle="modal" data-target="#modalEdit-<?php echo e($item->id_kelas); ?>">
												<i class="fas fa-edit"></i>
											</a>
											<form action="javascript:" method="POST" class="d-inline" id="form-hapus">
												<?php echo method_field('delete'); ?>
												<button rel="<?php echo e($item->id_kelas); ?>" rel1="delete" href="javascript:" class="btn btn-danger hapus_data">
													<i class="fas fa-trash"></i>
												</button>
											</form>
										</td>
                        			</tr>
                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Start modal tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Kelas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(url('/kelas/tambah')); ?>" method="POST">
      <div class="modal-body">
         <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="kelas" class="col-form-label">Kelas</label>

            <input type="text" name="kelas" class="form-control" id="kelas">
          </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Simpan">

      </div>
      </form>
    </div>
  </div>
</div>
<!-- End modal tambah -->

<!-- Start modal Edit -->
<?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalEdit-<?php echo e($kel->id_kelas); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ubah Data Kelas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(url('/kelas/edit')); ?>" method="POST">
      <div class="modal-body">
         <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="kelas" class="col-form-label">Kelas</label>
            <input type="hidden" name="id_kelas" class="form-control" id="id_kelas" value="<?php echo e($kel->id_kelas); ?>">
            <input type="text" name="kelas" class="form-control" id="kelas" value="<?php echo e($kel->kelas); ?>">
          </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Simpan">

      </div>
      </form>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- End modal Edit -->
                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
	 $(document).ready(function(){
	 	$('.hapus_data').on('click', function(){
            var id = $(this).attr('rel');
            var deleteFuntiom = $(this).attr('rel1');
            Swal.fire({
                title : 'Hapus Data',
                text : 'Apakah kamu yakin ingin menghapus data ?',
                icon : 'warning',
                showCancelButton : true,
                confirmButtonColor : '#d33',
                cancelButtonColor : '#3085d6',
                confirmButtonText : 'Hapus'
                }).then((result) => {

                    if(result.isConfirmed){
                        window.location.href = "<?php echo e(url('/kelas/hapus')); ?>"+"/"+id;
                        
                }
            })
            console.log(id);
        });	
	 });

	 $(document).on('submit', 'form', function(event) {
	 	event.preventDefault();
	 	$.ajax({
	 		url : $(this).attr('action'),
	 		type : $(this).attr('method'),
	 		typeData : "JSON",
	 		data : new FormData(this),
	 		processData:false,
	 		contentType:false,
	 		success : function(res) {
	 			console.log(res);
	 			window.location.href = "<?php echo e(url('/kelas')); ?>"
	 			const Toast = Swal.mixin({
                            toast : true,
                            position : 'top-end',
                            showConfirmButton : false,
                            timer : 3000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                        Toast.fire({
                            icon : 'success',
                            title : 'Data Berhasil Ditambahkan'
                        })
		 		},
		 		error : function (xhr) {
		 			// toastr.error(res.responseJSON.text, 'Gagal');
		 			Swal.fire({
					  position: 'top-end',
					  icon: 'error',
					  title: xhr.responseJSON.text,
					  showConfirmButton: false,
					  timer: 1500
					})
		 		} 
	 	})
	 });		
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/kelas/index.blade.php ENDPATH**/ ?>