

<?php $__env->startSection('title'); ?>
  Rincian Tabungan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Data Rincian Tabungan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link_halaman'); ?>
  <a href="/">Dashboard </a> >> <a href="/orang_tua/tabungan/total"> Rincian Tabungan</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->orang_tua->nama_orangtua); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->

<div class="row">
    <div class="col-12">
    	
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                	
                		<?php echo csrf_field(); ?>
                	
                		
                	</div>
                	<div class="row">
                		<div class="col-sm-12">
                			<table>
                				<tr>
                					<td>NIS</td>
                					<td> : </td>
                					<td><?php echo e($data_siswa->nis); ?></td>
                				</tr>
                				<tr>
                					<td>Nama</td>
                					<td> : </td>
                					<td><?php echo e($data_siswa->nama_siswa); ?></td>
                				</tr>
                				<tr>
                					<td>Kelas</td>
                					<td> : </td>
                					<td><?php echo e($data_siswa->kelas->kelas); ?></td>
                				</tr>
                                <tr>
                                    <td>Nama Orang Tua</td>
                                    <td> : </td>
                                    <td><?php echo e($data_siswa->orang_tua->nama_orangtua); ?></td>
                                </tr>
                			</table>
                			<hr class="mb-4">              	
		                    <table id="data_table" class="table data_table">
		                        <thead class="bg-primary text-white">
		                            <tr>
		                                <th scope="col" width="65px">No</th>
		                                <th scope="col">Tanggal Transaksi</th>
		                                <th scope="col">Debit</th>
		                                <th scope="col">Kredit</th>
		                                <th scope="col" width="130px">Nominal</th>
		                            </tr>
		                        </thead>
		                        <tbody>
		                        		<?php $__currentLoopData = $data_tabungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<tr>
                                                <td width="65px" scope="row"><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <?php echo e(date('d-m-Y', strtotime($item->tgl_transaksi))); ?>

                                                </td>
                                                <td width="40px">
                                                    <?php if($item->nominal_debit > 0): ?>
                                                        
                                                        
                                                        <h3 style="color: #20B2AA">&#10004;</h3>
                                                        <!--<h3 style="color: #00FA9A">&#10004;</h3>-->
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    
                                                    <?php if($item->nominal_kredit > 0): ?>
                                                        <h3 style="color: #20B2AA">&#10004;</h3>
                                                    <?php endif; ?>
                                                </td>
                                                <td width="130px">
                                                    
                                                    <?php if($item->nominal_kredit > 0): ?>
                                                        <?php echo number_format($item->nominal_kredit, 0, ',', '.'); ?>
                                                    <?php endif; ?>

                                                    <?php if($item->nominal_debit > 0): ?>
                                                        <?php echo number_format($item->nominal_debit, 0, ',', '.'); ?>
                                                    <?php endif; ?>


                                                </td>
                                            </tr>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        </tbody>
		                    </table>
		                    
                    	</div>
                    </div>
                    
                </div>
            </div>
        </div>
        <input type="submit" value="SIMPAN" class="ml-auto form-control btn btn-primary" style="width: 15%">
        
    </div>
</div>
                
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/orang_tua/rincian_tabungan.blade.php ENDPATH**/ ?>