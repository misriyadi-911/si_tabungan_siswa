

<?php $__env->startSection('title'); ?>
  Data Total Tabungan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Data Total Tabungan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link_halaman'); ?>
  <a href="<?php echo e(url('/')); ?>">Dashboard </a> >> <a href="<?php echo e(url('/siswa/tabungan/total')); ?>"> Total Tabungan</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->admin->nama_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foto_user'); ?>
    <?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->admin->foto_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->

<?php 

    use Illuminate\Support\Carbon;

?>

<div class="row">
    <div class="col-12">
    	
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                	
                		<?php echo csrf_field(); ?>
                	
                		
                	</div>
                	<div class="row">
                		<div class="col-sm-12">
                            <div class="row">
                                <div class="col-4 align-self-center">
                                    <table>
                                        <tr>
                                            <td>Bulan</td>
                                            <td> : </td>
                                            <td><?php echo e(Carbon::now()->isoFormat('MMMM')); ?></td>
                                            <td>
                                        </tr>
                                    </table>
                                </div>
                                
                                <div class="col-6 align-self-center">
                                    <div class="float-right">
                                        <form action="<?php echo e(url('tabungan/exportExcel')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                                <select name="bulan" id="" class="form-control">
                                                    <option value="<?php $dt = Carbon::now(); echo "0".$dt->month; ?>"><?php echo e(Carbon::now()->isoFormat('MMMM')); ?></option>
                                                    <hr><hr><hr>
                                                    <option value="01">Januari</option>
                                                    <option value="02">Februari</option>
                                                    <option value="03">Maret</option>
                                                    <option value="04">April</option>
                                                    <option value="05">Mei</option>
                                                    <option value="06">Juni</option>
                                                    <option value="07">Juli</option>
                                                    <option value="08">Agustus</option>
                                                    <option value="09">September</option>
                                                    <option value="10">Oktober</option>
                                                    <option value="11">November</option>
                                                    <option value="11">Desember</option>
                                                </select>

                                            <!-- <input type="submit" class="btn btn-sm btn-primary mt-3" value="Export Excel"> -->
                                        
                                    </div>
                                </div>
                                <div class="col-2 align-self-center">
                                    <div class="float-right">
                                            <?php echo csrf_field(); ?>

                                            <input type="submit" class="btn btn-sm btn-success" value="Export Excel">  
                                            </form>              
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row">
                                <div class="col-7 align-self-center">
                                    <table>
                                        <tr>
                                            
                                                
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                			
                            
                			<hr class="mb-4">              	
		                    <table id="data_table" class="table data_table">
                                <a href=""></a>
		                        <thead class="bg-primary text-white">
		                            <tr>
		                                <th scope="col" width="65px">No</th>
		                                <th scope="col">Nama</th>
                                        <th scope="col">Kelas</th>
                                        <th scope="col">Debit</th>
                                        <th scope="col">Kredit</th>
		                                <th scope="col" width="130px">Total</th>
		                            </tr>
		                        </thead>
		                        <tbody>
		                        		<?php $__currentLoopData = $data_tabungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<tr>
		                        				<td width="65px" scope="row"><?php echo e($loop->iteration); ?></td>
		                        				<td>
                                                   <?php echo e($item->siswa->nama_siswa); ?>

		                        					
		                        				</td>
		                        				<td>
		                        					<?php echo e($item->siswa->kelas->kelas); ?>                  					
		                        				</td>
                                                <td>
                                                    <?php echo number_format($item->total_debit, 0, ',', '.'); ?>
                                                </td>
                                                <td>
                                                    <?php echo number_format($item->total_kredit, 0, ',', '.'); ?>
                                                </td>
                                                <td>
                                                    <?php echo number_format($item->total_debit - $item->total_kredit, 0, ',', '.'); ?>
                                                </td>
		                        			</tr>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        </tbody>
		                    </table>
		                    
                    	</div>
                    </div>
                    
                </div>
            </div>
            <input type="submit" value="SIMPAN" class="ml-auto form-control btn btn-primary" style="width: 15%">
        </div>
        
    </div>
                
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views//tabungan/total_tabungan.blade.php ENDPATH**/ ?>