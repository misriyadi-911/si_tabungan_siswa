

<?php $__env->startSection('title'); ?>
  Total Tabungan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Data Total Tabungan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link_halaman'); ?>
  <a href="/">Dashboard </a> >> <a href="/siswa/tabungan/total"> Total Tabungan</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->admin->nama_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foto_user'); ?>
    <?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->admin->foto_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->

<div class="row">
    <div class="col-12">
    	
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                	
                		<?php echo csrf_field(); ?>
                	
                		
                	</div>
                	<div class="row">
                		<div class="col-sm-12">
                            <div class="row">
                                <div class="col-7 align-self-center">
                                    <table>
                                        <tr>
                                            <td>Bulan</td>
                                            <td> : </td>
                                            <td><?php echo e(date('M')); ?></td>
                                            <td>
                                                
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-5 align-self-center">
                                    <div class="float-right">
                                        <a href="<?php echo e(url('tabungan/export')); ?>" class="btn btn-sm btn-primary mt-3">Export Excel</a>
                                    </div>
                                </div>
                            </div>
                			
                            
                			<hr class="mb-4">              	
		                    <table id="data_table" class="table data_table">
                                <a href=""></a>
		                        <thead class="bg-primary text-white">
		                            <tr>
		                                <th scope="col" width="65px">No</th>
		                                <th scope="col">Nama</th>
                                        <th scope="col">Kelas</th>
                                        <th scope="col">Debit</th>
                                        <th scope="col">Kredit</th>
		                                <th scope="col" width="130px">Total</th>
		                            </tr>
		                        </thead>
		                        <tbody>
		                        		<?php $__currentLoopData = $data_tabungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<tr>
		                        				<td width="65px" scope="row"><?php echo e($loop->iteration); ?></td>
		                        				<td>
                                                   <?php echo e($item->siswa->nama_siswa); ?>

		                        					
		                        				</td>
		                        				<td>
		                        					<?php echo e($item->siswa->kelas->kelas); ?>                  					
		                        				</td>
                                                <td>
                                                    @currency($item->total_debit)
                                                </td>
                                                <td>
                                                    @currency($item->total_kredit)
                                                </td>
                                                <td>
                                                    @currency($item->total_debit - $item->total_kredit)
                                                </td>
		                        			</tr>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        </tbody>
		                    </table>
		                    
                    	</div>
                    </div>
                    
                </div>
            </div>
            <input type="submit" value="SIMPAN" class="ml-auto form-control btn btn-primary" style="width: 15%">
        </div>
        
    </div>
                
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/tabungan/total_tabungan.blade.php ENDPATH**/ ?>