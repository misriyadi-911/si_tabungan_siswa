

<?php $__env->startSection('title'); ?>
  Input Data Tabungan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Data Tabungan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link_halaman'); ?>
  <a href="<?php echo e(url('/beranda')); ?>">Dashboard </a> >> <a href="<?php echo e(url('/tabungan/tambah')); ?>"> Input Data Tabungan</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->admin->nama_admin); ?>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('foto_user'); ?>
    <?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->admin->foto_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->
<form action="<?php echo e(url('/tabungan/tambah')); ?>" method="post">
<div class="row">
    <div class="col-12">
    	
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                	
                		<?php echo csrf_field(); ?>
                	<div class="row">
                		<div class="col-lg-4">
                			<input type="date" name="tgl_transaksi" class="form-control mb-3" width="30%">
                		</div>
                		<div class="col-lg-4">
                			<input type="hidden" name="id_tapel" class="form-control mb-3" width="30%" value="<?php echo e($data_tapel[0]->id_tapel); ?>">
                		</div>
                	</div>
                	<div class="row">
                		<div class="col-sm-12">	                	
		                    <table id="data_table" class="table data_table">
		                        <thead class="bg-primary text-white">
		                            <tr>
		                                <th scope="col" width="65px">No</th>
		                                <th scope="col" width="165px">NIS</th>
		                                <th scope="col">Nama</th>
		                                <th scope="col">Kelas</th>
		                                <th scope="col">Nominal Debit</th>
		                                <th scope="col">Nominal Kredit</th>
		                            </tr>
		                        </thead>
		                        <tbody>
		                        		<?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<tr>
		                        				<td width="65px" scope="row"><?php echo e($loop->iteration); ?></td>
		                        				<td>
		                        					<input type="hidden" name="id_siswa[]" value="<?php echo e($item->id_siswa); ?>">
		                        					<input type="text" name="nis[]" class="hiddenForm form-control" value="<?php echo e($item->nis); ?>" disabled="">
		                        				</td>
		                        				<td width="165px">
		                        					<input type="text" name="nama_siswa[]" class="hiddenForm  form-control" value="<?php echo e($item->nama_siswa); ?>" disabled="">
		                        				</td>
		                        				<td width="40">
		                        					<input type="text" name="kelas[]" class="hiddenForm  form-control" value="<?php echo e($item->kelas->kelas); ?>" disabled="">
		                        				</td>
		                        				<td>
		                        					<div class="form-group">
		                        						<input type="text" name="nominal_debit[]" class="form-control" value="0">
		                        					</div>                        					
		                        				</td>
		                        				<td>
		                        					<div class="form-group">
		                        						<input type="text" name="nominal_kredit[]" class="form-control" value="0">
		                        					</div>                        					
		                        				</td>
		                        			</tr>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        </tbody>
		                    </table>
		                    
                    	</div>
                    </div>
                    
                </div>
            </div>
        </div>
        <input type="submit" value="SIMPAN" class="ml-auto form-control btn btn-primary" style="width: 15%">

        
    </div>
</div>
</form>
                
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/tabungan/input_transaksi.blade.php ENDPATH**/ ?>