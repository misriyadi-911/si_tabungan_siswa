

<?php $__env->startSection('title'); ?>
  Total Tabungan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
  Data Total Tabungan Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link_halaman'); ?>
  <a href="<?php echo e(url('/siswa/dashboard')); ?>">Dashboard </a> >> <a href="<?php echo e(url('/siswa/tabungan/total')); ?>"> Total Tabungan</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
    <?php echo e(auth()->user()->siswa->nama_siswa); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foto_user'); ?>
    <?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->siswa->foto_siswa); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->

<?php 

    use Illuminate\Support\Carbon;

?>

<form action="/transaksi/tambah" method="post">
<div class="row">
    <div class="col-12">
    	
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                	
                		<?php echo csrf_field(); ?>
                	
                		
                	</div>
                	<div class="row">
                		<div class="col-sm-12">
                			<table>
                				<tr>
                					<td>NIS</td>
                					<td> : </td>
                					<td><?php echo e($data_siswa->nis); ?></td>
                				</tr>
                				<tr>
                					<td>Nama</td>
                					<td> : </td>
                					<td><?php echo e($data_siswa->nama_siswa); ?></td>
                				</tr>
                				<tr>
                					<td>Kelas</td>
                					<td> : </td>
                					<td><?php echo e($data_siswa->kelas->kelas); ?></td>
                				</tr>
                			</table>
                			<hr class="mb-4">              	
		                    <table id="data_table" class="table data_table">
		                        <thead class="bg-primary text-white">
		                            <tr>
		                                <th scope="col" width="65px">No</th>
		                                <th scope="col">Bulan</th>
		                                <th scope="col" width="130px">Total</th>
		                            </tr>
		                        </thead>
		                        <tbody>
		                        		<?php $__currentLoopData = $data_tabungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<tr>
		                        				<td width="65px" scope="row"><?php echo e($loop->iteration); ?></td>
		                        				<td>
                                                   <?php echo e(Carbon::parse(date('M', strtotime($data_tabungan[0]->tgl_transaksi)))->isoFormat('MMMM')); ?>

		                        					
		                        				</td>
		                        				<td>
		                        					<?php echo number_format($total, 0, ',', '.'); ?>                  					
		                        				</td>
		                        			</tr>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        </tbody>
		                    </table>
		                    
                    	</div>
                    </div>
                    
                </div>
            </div>
        </div>
        <input type="submit" value="SIMPAN" class="ml-auto form-control btn btn-primary" style="width: 15%">
        
    </div>
</div>
</form>
                
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views//siswa/total_tabungan.blade.php ENDPATH**/ ?>