

<?php $__env->startSection('title'); ?>
Data Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_halaman'); ?>
Data Siswa
<?php $__env->stopSection(); ?>


<?php $__env->startSection('link_halaman'); ?>
<a href="<?php echo e(url('/beranda')); ?>">Dashboard </a> >> <a href="<?php echo e(url('/siswa')); ?>"> Siswa</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user'); ?>
<?php echo e(auth()->user()->admin->nama_admin); ?>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('foto_user'); ?>
<?php echo e(asset('img')); ?>/<?php echo e(auth()->user()->admin->foto_admin); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<!-- basic table -->
<div class="row">
	<div class="col-12">
		<a href="" class="btn btn-primary btn-sm rounded-pill mb-3 btn_tambah" data-toggle="modal" data-target="#modalTambah">
			<i class="fas fa-plus-circle"></i> Tambah Data Siswa
		</a>
		<div class="card">
			<div class="card-body">
				<div class="table-responsive">
					<table id="data_table" class="table data_table">
						<thead class="bg-primary text-white">
							<tr>
								<th scope="col">No</th>
								<th scope="col">NIS</th>
								<th scope="col">Nama</th>
								<th scope="col">Kelas</th>
								<th scope="col">Alamat</th>
								<th scope="col">Jenis Kelamin</th>
								<th scope="col">No HP</th>
								<th scope="col" width="150px">Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td scope="row"><?php echo e($loop->iteration); ?></td>
								<td><?php echo e($item->nis); ?></td>
								<td><?php echo e($item->nama_siswa); ?></td>
								<td><?php echo e($item->kelas->kelas); ?></td>
								<td><?php echo e($item->alamat_siswa); ?></td>
								<td><?php echo e($item->jenis_kelamin_siswa); ?></td>
								<td><?php echo e($item->nohp_siswa); ?></td>
								<td width="150px" class="text-center">
									<a href="" class="btn btn-success" data-toggle="modal" data-target="#modalDetail-<?php echo e($item->id_siswa); ?>">
										<i class="fas fa-eye"></i>
									</a>			

									<a href="" class="btn btn-info" data-toggle="modal" data-target="#modalEdit-<?php echo e($item->id_siswa); ?>">
										<i class="fas fa-edit" ></i>
									</a>

									<a href="javascript:" class="btn btn-danger hapus_data" rel="<?php echo e($item->id_siswa); ?>">
										<i class="fas fa-trash"></i>
									</a>
									<a href="javascript:" class="btn btn-danger luluskan mt-3" rel="<?php echo e($item->id_siswa); ?>">
										<div class="badge">Luluskan Siswa</div>
									</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>


<!-- Start modal tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Tambah Data Siswa</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?php echo e(url('/siswa/tambah')); ?>" method="POST" enctype="multipart/form-data">
				<div class="modal-body">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="level" value="siswa">
					<div class="row">
						<div class="col-md-12 col-lg-12">
							<div class="card">
								<div class="card-body">
									<div class="d-flex align-items-start">
										<h3 class="card-title mb-0">Data Siswa</h3>
									</div>
									<hr>
									<div class="row">
										<div class="col-md-6">
											<?php echo csrf_field(); ?>
											<div class="form-group">
												<label for="nis">NIS</label>
												<input name="nis" type="text" class="form-control <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nis">
												<?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<p class="text-danger text-sm"><?php echo e($message); ?></p>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
											<div class="form-group">
												<h5 id="nama_siswa">Nama</h5>
												<input name="nama_siswa" type="text" class="form-control" id="nama_siswa">
											</div>
											<div class="form-group">
												<label for="alamat_siswa">Alamat</label>
												<input name="alamat_siswa" id="alamat_siswa" cols="30" rows="5" class="form-control"></input>
											</div>
											<div class="form-group">
												<label for="nohp_siswa">No HP</label>
												<input name="nohp_siswa" type="text" class="form-control" id="nohp_siswa">
											</div>

											<div class="form-group">
												<label for="jenis_kelamin_siswa">Jenis Kelamin</label>
												<select name="jenis_kelamin_siswa" id="jenis_kelamin_siswa" class="form-control">
													<option value="Laki-laki">Laki-laki</option>
													<option value="Perempuan">Perempuan</option>
												</select>
											</div>
										</div>

										<div class="col-md-6">                           

											<div class="form-group">
												<label for="kelas">Kelas</label>
												<select name="kelas" id="kelas" class="form-control">
													<option value="1">X</option>
													<option value="2">XI</option>
													<option value="3">XII</option>
												</select>
											</div>
											<div class="form-group">
												<label for="foto_siswa">Foto</label>
												<input name="foto_siswa" type="file" name="foto_siswa" class="form-control" id="foto_siswa">
											</div>
											<div class="form-group">
												<label for="username">Username</label>
												<input name="username" type="text" class="form-control" id="username">
											</div>
											<div class="form-group">
												<label for="password">Password</label>
												<input name="password" type="password" class="form-control" id="password">
											</div>
										</div>
									</div>	                                
								</div>
							</div>
						</div>

					</div>

					<div class="row">
						<div class="col-md-12 col-lg-12">
							<div class="card">
								<div class="card-body">
									<div class="d-flex align-items-start">
										<h3 class="card-title mb-0">Data Orang Tua</h3>
									</div>
									<hr>
									<div class="form-group">
										<label for="nama_orangtua">Nama Orang Tua/Wali</label>
										<input name="nama_orangtua" type="text" class="form-control" id="nama_orangtua">
									</div>
									<div class="form-group">
										<label for="alamat_orangtua">Alamat</label>
										<input name="alamat_orangtua" type="text" class="form-control" id="alamat_orangtua">
									</div>
									<div class="form-group">
										<label for="nohp_orangtua">No HP</label>
										<input name="nohp_orangtua" type="number" class="form-control" id="nohp_orangtua">
									</div>                                
								</div>
							</div>
						</div>

					</div>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary btn-tutup" data-dismiss="modal">Close</button>
					<input type="submit" class="btn btn-primary" value="Simpan">

				</div>
			</form>
		</div>
	</div>
</div>
<!-- End modal tambah -->

<!-- Start modal Detail -->
<?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalDetail-<?php echo e($siswa->id_siswa); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Detail Data Siswa</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="card">
					<div class="row">
						<div class="col-md-4">
							<img class="card-img-top img-fluid" src="<?php echo e(asset('img')); ?>/<?php echo e($siswa->foto_siswa); ?>"
							alt="Card image cap" style="width: : 80%">
						</div>
						<hr>
						<div class="col-md-8">
							<div class="row">
								<div class="col-6">Nama Siswa</div>
								<div class="col-6">: <?php echo e($siswa->nama_siswa); ?></div>
							</div>
							<div class="row">
								<div class="col-6">NIS</div>
								<div class="col-6">: <?php echo e($siswa->nis); ?></div>
							</div>
							<div class="row">
								<div class="col-6">Alamat</div>
								<div class="col-6">: <?php echo e($siswa->alamat_siswa); ?></div>
							</div>
							<div class="row">
								<div class="col-6">No HP</div>
								<div class="col-6">: <?php echo e($siswa->nohp_siswa); ?></div>
							</div>
							<div class="row">
								<div class="col-6">Jenis Kelamin</div>
								<div class="col-6">: <?php echo e($siswa->jenis_kelamin_siswa); ?></div>
							</div>
							<div class="row">
								<div class="col-6">Kelas</div>
								<div class="col-6">: <?php echo e($siswa->kelas->kelas); ?></div>
							</div>
							<div class="row">
								<div class="col-6">No Rekening</div>
								<div class="col-6">: <?php echo e($siswa->no_rekening); ?></div>
							</div>
							<hr>
							<div class="row">
								<div class="col-6">Nama Orang Tua</div>
								<div class="col-6">: <?php echo e($siswa->orang_tua->nama_orangtua); ?></div>
							</div>
							<div class="row">
								<div class="col-6">Alamat Orang Tua</div>
								<div class="col-6">: <?php echo e($siswa->orang_tua->alamat_orangtua); ?></div>
							</div>
							<div class="row">
								<div class="col-6">No HP Orang Tua</div>
								<div class="col-6">: <?php echo e($siswa->orang_tua->nohp_orangtua); ?></div>
							</div>
						</div>
					</div>
						<!-- <img class="card-img-top img-fluid" src="<?php echo e(asset('img')); ?>/<?php echo e($siswa->foto_siswa); ?>" alt="Card image cap" style="width: : 80%">
						<div class="card-body">
							<h4 class="card-title"><?php echo e($siswa->nama_siswa); ?></h4>
							<hr>
							<p class="card-text">NIS : <?php echo e($siswa->nis); ?></p>
							<p class="card-text">Alamat : <?php echo e($siswa->alamat_siswa); ?></p>
							<p class="card-text">No HP : <?php echo e($siswa->nohp_siswa); ?></p>
							<p class="card-text">Jenis Kelamin : <?php echo e($siswa->jenis_kelamin_siswa); ?></p>
							<p class="card-text">Kelas : <?php echo e($siswa->kelas->kelas); ?></p>
							<p class="card-text">No Rekening : <?php echo e($siswa->no_rekening); ?></p>
							<hr>
							<p class="card-text">Nama Orang Tua : <?php echo e($siswa->orang_tua->nama_orangtua); ?></p>
							<p class="card-text">Alamat Orang Tua : <?php echo e($siswa->orang_tua->alamat_orangtua); ?></p>
							<p class="card-text">No HP Orang Tua : <?php echo e($siswa->orang_tua->nohp_orangtua); ?></p>
						</div> -->
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<!-- End modal Detail -->

<!-- Start modal Edit -->
<?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalEdit-<?php echo e($siswa->id_siswa); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Ubah Data Siswa</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?php echo e(url('/siswa/edit')); ?>" method="POST" enctype="multipart/form-data">
				<div class="modal-body">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="level" value="siswa">
					<input type="hidden" name="id_siswa" value="<?php echo e($siswa->id_siswa); ?>">
					<div class="row">
						<div class="col-md-12 col-lg-12">
							<div class="card">
								<div class="card-body">
									<div class="d-flex align-items-start">
										<h3 class="card-title mb-0">Edit Data Siswa</h3>
									</div>
									<hr>
									<div class="row">
										<div class="col-md-6">
											<?php echo csrf_field(); ?>
											<div class="form-group">
												<label for="nis">NIS</label>
												<input name="nis" type="text" class="form-control" id="nis" disabled="" value="<?php echo e($siswa->nis); ?>">
											</div>
											<div class="form-group">
												<h5 id="nama_siswa">Nama</h5>
												<input name="nama_siswa" type="text" class="form-control" id="nama_siswa" value="<?php echo e($siswa->nama_siswa); ?>">
											</div>
											<div class="form-group">
												<label for="alamat_siswa">Alamat</label>
												<input name="alamat_siswa" id="alamat_siswa" cols="30" rows="5" class="form-control" value="<?php echo e($siswa->alamat_siswa); ?>"></input>
											</div>
											<div class="form-group">
												<label for="nohp_siswa">No HP</label>
												<input name="nohp_siswa" type="text" class="form-control" id="nohp_siswa" value="<?php echo e($siswa->nohp_siswa); ?>">
											</div>
										</div>

										<div class="col-md-6">

											<div class="form-group">
												<label for="jenis_kelamin_siswa">Jenis Kelamin</label>
												<select name="jenis_kelamin_siswa" id="jenis_kelamin_siswa" class="form-control">
													<option value="<?php echo e($siswa->jenis_kelamin_siswa); ?>"><?php echo e($siswa->jenis_kelamin_siswa); ?></option>
													<option value="" disabled="">-- Pilih Jenis Kelamin --</option>
													<option value="Laki-laki">Laki-laki</option>
													<option value="Perempuan">Perempuan</option>
												</select>
											</div>
											<div class="form-group">
												<label for="kelas">Kelas</label>
												<select name="kelas" id="kelas" class="form-control">
													<option value="<?php echo e($siswa->kelas->id_kelas); ?>"><?php echo e($siswa->kelas->kelas); ?></option>
													<option value="" disabled="">-- Pilih Kelas --</option>
													<option value="1">X</option>
													<option value="2">XI</option>
													<option value="3">XII</option>
												</select>
											</div>
											<div class="form-group">
												<label for="foto_siswa">Foto</label>
												<img src="<?php echo e(asset('img')); ?>/<?php echo e($siswa->foto_siswa); ?>" width="50%">
												<input type="hidden" name="foto_lama" value="<?php echo e($siswa->foto_siswa); ?>">
												<input name="foto_siswa" type="file" class="form-control" id="foto_siswa" value="<?php echo e($siswa->foto_siswa); ?>" >
											</div>
										</div>
									</div>	                                
								</div>
							</div>
						</div>

					</div>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<input type="submit" class="btn btn-primary" value="Simpan">

				</div>
			</form>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<!-- End modal Edit -->

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('script'); ?>
	<script>
		$(document).ready(function(){
		// Swal.fire({
		//   position: 'top-end',
		//   icon: 'error',
		//   title: 'Your work has been saved',
		//   showConfirmButton: false,
		//   timer: 1500
		// })
		$('.hapus_data').on('click', function(){
			var id = $(this).attr('rel');
			Swal.fire({
				title : 'Hapus Data',
				text : 'Apakah kamu yakin ingin menghapus data ?',
				icon : 'warning',
				showCancelButton : true,
				confirmButtonColor : '#d33',
				cancelButtonColor : '#3085d6',
				confirmButtonText : 'Hapus'
			}).then((result) => {

				if(result.isConfirmed){
					window.location.href = "<?php echo e(url ('/siswa/hapus')); ?>"+"/"+id;

				}
			})
			console.log(id);
		});

		$('.luluskan').on('click', function(){
			var id = $(this).attr('rel');
			Swal.fire({
				title : 'Luluskan Siswa',
				text : 'Apakah kamu yakin ingin meluluskan siswa ? Siswa yang diluluskan akan terhapus dari data siswa',
				icon : 'warning',
				showCancelButton : true,
				confirmButtonColor : '#d33',
				cancelButtonColor : '#3085d6',
				confirmButtonText : 'Luluskan'
			}).then((result) => {

				if(result.isConfirmed){
					window.location.href = "<?php echo e(url ('/siswa/hapus')); ?>"+"/"+id;

				}
			})
			console.log(id);
		});	
	});

		$(document).on('submit', 'form', function(event) {
			event.preventDefault();
			$.ajax({
				url : $(this).attr('action'),
				type : $(this).attr('method'),
				typeData : "JSON",
				data : new FormData(this),
				processData:false,
				contentType:false,
				success : function(res) {
					console.log(res);
					window.location.href = "<?php echo e(url('/siswa')); ?>"
					const Toast = Swal.mixin({
						toast : true,
						position : 'top-end',
						showConfirmButton : false,
						timer : 3000,
						timerProgressBar: true,
						didOpen: (toast) => {
							toast.addEventListener('mouseenter', Swal.stopTimer)
							toast.addEventListener('mouseleave', Swal.resumeTimer)
						}
					})
					Toast.fire({
						icon : 'success',
						title : res.text
					})
				},
				error : function (xhr) {
		 			// toastr.error(res.responseJSON.text, 'Gagal');
		 			Swal.fire({
		 				position: 'top-end',
		 				icon: 'error',
		 				title: xhr.responseJSON.text,
		 				showConfirmButton: false,
		 				timer: 1500
		 			})
		 		} 
		 	})
		});		
	</script>
	<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel8\resources\views/siswa/index.blade.php ENDPATH**/ ?>